<?php
// RapidGator premium plugin, rewritten for PHP 8.3.
// Drop-in replacement for the old Th3-822 rapidgator_net plugin, same class name,
// same config key ($GLOBALS['premium_acc']['rapidgator_net']) and same
// RedirectDownload() hand-off, so the rest of RapidLeech does not change.
//
// What changed, and why:
// - No longer uses the old core cURL() socket transport, GetCookiesArr(),
//   encrypt()/decrypt() or the cookie-storage file. Those are the pieces that
//   only this plugin exercises, and that is where a PHP 8 break hides while
//   direct downloads still work. This version uses the php-curl extension
//   directly, with its own in-memory cookie handling.
// - All PHP 8.1+ hazards are guarded: no undefined array keys (?? everywhere),
//   no null/false passed to string functions, no array_combine() on
//   mismatched counts, no curly-brace offsets, no removed functions.
// - Login logic, download-link regexp and error messages are kept from the
//   old plugin, because that plugin still works on PHP < 8 hosts, so those
//   parts are proven against the current RapidGator site.
// - Requires php-curl on the new host (php8.3-curl). If it is missing the
//   plugin says so explicitly instead of failing mysteriously.
// - Premium login normally needs no CAPTCHA. If RapidGator does demand one
//   (new IP, frequent logins), this version reports it clearly instead of
//   trying to drive the old core CAPTCHA flow.
// - On the server, rename this file to the exact filename your RapidLeech
//   install loads for RapidGator, and back up the original first.
// v2 (2026-10-27) changes vs v1:
// - Form credentials are primary. No accounts.php / config.php account is
//   required: paste the link, type user/password in the web form, download.
//   Config ($GLOBALS['premium_acc']['rapidgator_net']) is only a fallback
//   when the form is empty.
// - pA_encrypted handling no longer depends on core decrypt(): if decrypt()
//   exists it is tried, but a garbage/failed result falls back to the raw
//   form value and lets the login result decide, instead of dying inside
//   a possibly PHP 8.3-broken core function. This version never generates
//   an intermediate form, so it never needs core encrypt() at all.
// - Direct-link resolver is no longer old-regexp-only. Modern premium
//   redirects can be https://c***.rapidgator.net/..., a token-signed
//   independent CDN host, or an rg.to / storage-node URL. Those are
//   accepted in priority order below, and the link is used immediately
//   (token links are short-lived and must not be cached).

if (!defined('RAPIDLEECH')) {
	require_once('index.html');
	exit();
}

class rapidgator_net extends DownloadClass {
	private $baseUrl = 'https://rapidgator.net/';
	private $link = '';
	private $cookies = array();
	private $referer = '';
	private $DLregexp = '@https?://(?:pr|(s))\d+\.rapidgator\.net/(?(1)download/)[^\s\"\'<>]+@i';

	public function Download($link) {
		$parts = parse_url($link);
		if (!is_array($parts) || empty($parts['path'])) {
			html_error('Invalid RapidGator link.');
		}
		$path = $parts['path'];
		$query = !empty($parts['query']) ? '?' . $parts['query'] : '';
		$this->link = 'https://rapidgator.net' . $path . $query;
		$this->cookies = array('lang' => 'en');
		$this->referer = $this->link;

		// Initial file page: file must exist before we spend a login on it.
		$first = $this->http($this->link, array(), $this->link);
		if (stripos($first['body'], '>File not found<') !== false) {
			html_error('File not found.');
		}

		// Form-first: the normal workflow is typing user/password in the
		// web form. Config is only a fallback, never a requirement, and no
		// accounts.php file is read at all.
		$user = $this->resolveCredential($_REQUEST['premium_user'] ?? '', true);
		$pass = $this->resolveCredential($_REQUEST['premium_pass'] ?? '', false);
		if ($user === '') $user = $GLOBALS['premium_acc']['rapidgator_net']['user'] ?? '';
		if ($pass === '') $pass = $GLOBALS['premium_acc']['rapidgator_net']['pass'] ?? '';
		if ($user === '' || $pass === '') {
			html_error('Login Failed: User or Password is empty. Enter the premium account in the download form.');
		}

		$this->login((string)$user, (string)$pass);
		$this->premiumDownload();
	}

	// Resolve one form credential. Plain form values (the normal case)
	// are returned as-is. Only when the old pA_encrypted flag is present
	// is core decrypt() tried, and only a plausible result is trusted:
	// an email-looking value for the user, a non-empty value for the
	// password. A failed/garbage decrypt falls back to the raw value
	// instead of failing inside core code.
	private function resolveCredential($raw, $isUser) {
		if (!is_string($raw) || $raw === '') return '';
		if (empty($_REQUEST['pA_encrypted']) || !function_exists('decrypt')) {
			return $raw;
		}
		$candidates = array_unique(array($raw, urldecode($raw)));
		foreach ($candidates as $candidate) {
			$dec = decrypt($candidate);
			if (!is_string($dec) || $dec === '') continue;
			if ($isUser) {
				if (strpos($dec, '@') !== false) return $dec;
			} else {
				return $dec;
			}
		}
		return $raw;
	}

	private function login($user, $pass) {
		$post = array(
			'LoginForm[email]' => $user,
			'LoginForm[password]' => $pass,
			'LoginForm[rememberMe]' => '1',
		);
		$res = $this->http($this->baseUrl . 'auth/login', $post, $this->link);
		$body = $res['body'];

		if (stripos($body, 'Wrong e-mail or password.') !== false) {
			html_error('Login Failed: Email/Password incorrect.');
		}
		if (stripos($body, 'E-mail is not a valid email address.') !== false) {
			html_error('Login Failed: Login isn\'t an email address.');
		}
		if (stripos($body, 'Frequent logins.') !== false) {
			html_error('Too frequent logins, please wait and try again.');
		}
		if (stripos($body, 'unusual location') !== false) {
			html_error('Login Failed: Login Blocked By IP, Check Account Email And Follow The Steps To Add IP to Whitelist.');
		}
		if (stripos($body, 'The code from a picture does not coincide') !== false) {
			html_error('Login Failed: RapidGator demands a CAPTCHA for this login (new IP or frequent logins). Complete one login in a browser from this server IP, then retry.');
		}
		if (empty($this->cookies['user__'])) {
			html_error("Login Error: Cannot find 'user__' cookie. Login did not complete - check password, IP whitelist, and whether the account is still premium.");
		}

		// Premium check, same signal as the old plugin.
		$home = $this->http($this->baseUrl, array(), $this->baseUrl . 'auth/login');
		if (stripos($home['body'], '>Free</a>') !== false) {
			html_error("Account isn't premium.");
		}
	}

	private function premiumDownload() {
		// One request only, no redirect following: if RapidGator redirects
		// straight to a download host we must use that URL, not buffer a file.
		$res = $this->httpOnce($this->link, array(), $this->link);
		$body = is_string($res['body']) ? $res['body'] : '';

		if (preg_match('@You have reached quota of downloaded information for premium accounts. At the moment, the quota is \d+ [GT]B(?: per \d+ day\(s\))?@i', $body, $err)) {
			html_error($err[0]);
		}

		$dlink = $this->extractDirectLink($res, $body);
		if ($dlink === '') {
			html_error('Error: Download-link not found.');
		}
		// Token-signed CDN links are short-lived: hand off immediately,
		// do not cache, do not re-login first.
		$this->RedirectDownload($dlink, 'rapidgatorpr');
	}

	// Modern premium direct links, in priority order. The old pr/s regexp
	// is kept for compatibility, but it is no longer the only accepted form.
	private function extractDirectLink($res, $body) {
		// 1. HTTP redirect straight to a download host / CDN.
		$location = '';
		if (preg_match('/^Location:\s*(.+)$/mi', $res['headers'], $m)) {
			$location = trim($m[1]);
		}
		if ($location !== '') {
			$abs = $this->absoluteUrl($res['url'], $location);
			if ($abs !== $this->link && stripos($abs, '/auth/') === false && stripos($abs, '/site/') === false) {
				return $abs;
			}
		}
		// 2. Old pr/s pattern, on the final URL and on the page.
		if (preg_match($this->DLregexp, $res['url'], $m)) return $m[0];
		if (preg_match($this->DLregexp, $body, $m)) return $m[0];
		// 3. JSON download URL fields are covered by the generic URL
		// scan in step 4 below, so no separate fragile JSON regex is used.
		// 4. Generic candidates from the page, two passes so a token or
		// /download/ link wins over an unrelated CDN/static link.
		$candidates = array();
		if (preg_match_all('@https?://[^\s"\'<>]+@i', $body, $am)) {
			foreach ($am[0] as $raw) {
				$candidate = rtrim(str_replace('\\/', '/', $raw), '.,;:');
				if ($candidate !== '' && !in_array($candidate, $candidates, true)) $candidates[] = $candidate;
			}
		}
		for ($pass = 0; $pass < 2; $pass++) {
			foreach ($candidates as $candidate) {
				if ($candidate === $this->link) continue;
				if (stripos($candidate, '/auth/') !== false || stripos($candidate, '/site/') !== false) continue;
				if (preg_match('/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff2?)(\?|$)/i', $candidate)) continue;
				if (substr($candidate, -5) === '.html' && stripos($candidate, 'token') === false && stripos($candidate, 'sig') === false) continue;
				$host = parse_url($candidate, PHP_URL_HOST);
				if (!is_string($host) || $host === '') continue;
				$path = parse_url($candidate, PHP_URL_PATH) ?? '';
				$query = parse_url($candidate, PHP_URL_QUERY) ?? '';
				$isSubdomain = (bool)preg_match('/\.rapidgator\.net$/i', $host) && strtolower($host) !== 'rapidgator.net' && strtolower($host) !== 'www.rapidgator.net';
				$isExternalCDN = strtolower($host) !== 'rapidgator.net' && strtolower($host) !== 'www.rapidgator.net' && !$isSubdomain;
				$hasDownload = stripos($path, '/download/') !== false;
				$hasToken = stripos($query, 'token') !== false || stripos($query, 'sig') !== false || stripos($query, 'expires') !== false || stripos($query, 'hash') !== false || stripos($candidate, 'token') !== false;
				if ($pass === 0) {
					if ($hasDownload || $hasToken || $isSubdomain) return $candidate;
				} else {
					if ($isExternalCDN || $isSubdomain) return $candidate;
				}
			}
		}
		// 5. Relative /download/... link in an href/action attribute.
		if (preg_match('@(?:href|action|data-url)="([^"]*(?:/download/|token)[^"]*)"@i', $body, $rm)) {
			return $this->absoluteUrl($this->link, $rm[1]);
		}
		return '';
	}

	// Follow HTTP redirects, keeping cookies and referer across hops.
	private function http($url, $post = array(), $referer = '') {
		$currentUrl = $url;
		$currentPost = $post;
		$currentReferer = $referer;
		for ($i = 0; $i < 10; $i++) {
			$res = $this->httpOnce($currentUrl, $currentPost, $currentReferer);
			$code = $res['code'];
			$location = '';
			if (preg_match('/^Location:\s*(.+)$/mi', $res['headers'], $m)) {
				$location = trim($m[1]);
			}
			if ($location !== '' && $code >= 300 && $code < 400) {
				$currentReferer = $currentUrl;
				$currentUrl = $this->absoluteUrl($currentUrl, $location);
				$currentPost = array();
				continue;
			}
			$res['url'] = $currentUrl;
			return $res;
		}
		html_error('Too many redirects from rapidgator.');
	}

	// Exactly one request, no redirect following.
	private function httpOnce($url, $post = array(), $referer = '') {
		if (!function_exists('curl_init')) {
			html_error('php-curl is not installed on this host. Install php8.3-curl and retry.');
		}
		$ch = curl_init();
		if ($ch === false) {
			html_error('cURL could not be initialised.');
		}
		$headers = array(
			'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language: en-US,en;q=0.9',
		);
		$cookieHeader = $this->cookieHeader();
		if ($cookieHeader !== '') {
			$headers[] = 'Cookie: ' . $cookieHeader;
		}
		if ($referer !== '') {
			$headers[] = 'Referer: ' . $referer;
		}
		curl_setopt_array($ch, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_HEADER => true,
			CURLOPT_FOLLOWLOCATION => false,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_SSL_VERIFYHOST => 2,
			CURLOPT_CONNECTTIMEOUT => 30,
			CURLOPT_TIMEOUT => 60,
			CURLOPT_ENCODING => '',
			CURLOPT_HTTPHEADER => $headers,
		));
		if (!empty($post)) {
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
		}
		$response = curl_exec($ch);
		if ($response === false) {
			$err = curl_error($ch);
			curl_close($ch);
			html_error('cURL request to rapidgator failed: ' . $err);
		}
		$headerSize = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
		curl_close($ch);
		$respHeaders = substr($response, 0, $headerSize);
		$body = substr($response, $headerSize);
		if (!is_string($respHeaders)) $respHeaders = '';
		if (!is_string($body)) $body = '';
		$this->parseCookies($respHeaders);
		return array('code' => $code, 'headers' => $respHeaders, 'body' => $body, 'url' => $url);
	}

	private function parseCookies($headers) {
		if (preg_match_all('/^Set-Cookie:\s*([^=;\s]+)=([^;]*)/mi', $headers, $matches, PREG_SET_ORDER)) {
			foreach ($matches as $m) {
				$name = trim($m[1]);
				$value = trim($m[2]);
				if ($value === '') {
					unset($this->cookies[$name]);
				} else {
					$this->cookies[$name] = $value;
				}
			}
		}
	}

	private function cookieHeader() {
		$parts = array();
		foreach ($this->cookies as $name => $value) {
			$parts[] = $name . '=' . $value;
		}
		return implode('; ', $parts);
	}

	private function absoluteUrl($base, $location) {
		if (stripos($location, 'http://') === 0 || stripos($location, 'https://') === 0) {
			return $location;
		}
		if (strpos($location, '//') === 0) {
			return 'https:' . $location;
		}
		$parts = parse_url($base);
		$scheme = $parts['scheme'] ?? 'https';
		$host = $parts['host'] ?? 'rapidgator.net';
		if (strpos($location, '/') === 0) {
			return $scheme . '://' . $host . $location;
		}
		$path = $parts['path'] ?? '/';
		$dir = substr($path, 0, (int)strrpos($path, '/') + 1);
		return $scheme . '://' . $host . $dir . $location;
	}
}

// Rewritten 2026-10-27 for PHP 8.3: transport swapped from core cURL() to
// php-curl, cookie handling in-memory, no encrypt()/decrypt() or cookie-file
// dependency. Login fields, download regexp and premium check kept from the
// Th3-822 plugin (last updated 2020-02-17) because that plugin still works
// on PHP < 8 hosts.
