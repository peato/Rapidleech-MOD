<?php
// PHP 8 Compatible pcrypt class using OpenSSL
class pcrypt {
    private $key;
    private $mode;

    function __construct($key = '', $mode = 'ecb') {
        $this->key = $key;
        $this->mode = strtolower($mode);
    }

    function encrypt($text) {
        if ($this->mode === 'ecb') {
            $cipher = "DES-ECB";
            // OpenSSL ECB ģʽ����Ҫ IV������Ҫ���� key
            $key = substr(md5($this->key), 0, 8); 
            $padded = $this->pkcs5_pad($text, 8);
            $encrypted = openssl_encrypt($padded, $cipher, $key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING);
            return base64_encode($encrypted);
        }
        return $text;
    }

    function decrypt($text) {
        if ($this->mode === 'ecb') {
            $cipher = "DES-ECB";
            $key = substr(md5($this->key), 0, 8);
            $data = base64_decode($text);
            $decrypted = openssl_decrypt($data, $cipher, $key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING);
            return $this->pkcs5_unpad($decrypted);
        }
        return $text;
    }

    private function pkcs5_pad($text, $blocksize) {
        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);
    }

    private function pkcs5_unpad($text) {
        $pad = ord($text[strlen($text) - 1]);
        if ($pad > strlen($text)) return false;
        if (strspn($text, chr($pad), strlen($text) - $pad) != $pad) return false;
        return substr($text, 0, -1 * $pad);
    }
}
?>